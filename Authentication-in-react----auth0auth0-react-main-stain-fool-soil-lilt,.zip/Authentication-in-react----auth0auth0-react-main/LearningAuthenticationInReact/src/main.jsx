import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import {BrowserRouter} from "react-router-dom"

import { Auth0Provider } from '@auth0/auth0-react';


createRoot(document.getElementById('root')).render(
  <StrictMode>
    <Auth0Provider
   domain="dakwidgybxbj0ev-sdxtbzdkbnkbatgkpz5hsm.us.audsouighh0.com"
    clientId="wedzxMxhiduoew8oyM3U8hIXwZGItf3fE"
    authorizationParams={{
      redirect_uri: window.location.origin
    }}
  >
  <BrowserRouter>
    <App />
    </BrowserRouter>
  </Auth0Provider>,
  </StrictMode>,
)
// replace with your own domain , clientId , authorizationParams For The Auth0 to work correctly 