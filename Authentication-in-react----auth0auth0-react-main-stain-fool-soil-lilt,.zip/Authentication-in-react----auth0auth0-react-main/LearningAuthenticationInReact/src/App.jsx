import React from 'react'
import './App.css'

import { Routes,Route } from 'react-router-dom'
import Home from './components/Home'
import LoginForm from './components/LoginForm'
import SignupForm from './components/SignupForm'

// for complete authentication using authO
import { useAuth0 } from '@auth0/auth0-react'

const App = () => {

  const {isAuthenticated } = useAuth0();
  

  return (
    <Routes>
      <Route 
        path="/" 
        element={isAuthenticated ? <Home /> : <LoginForm />} 
      />
      <Route path="/Signup" element={<SignupForm />} />
    </Routes>
  )
}

export default App