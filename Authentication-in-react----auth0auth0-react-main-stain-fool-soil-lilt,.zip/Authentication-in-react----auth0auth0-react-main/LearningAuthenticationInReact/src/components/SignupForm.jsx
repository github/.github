import React from 'react'
import { Link } from 'react-router-dom'
import { useAuth0 } from '@auth0/auth0-react'

const SignupForm = () => {

    const { loginWithRedirect } = useAuth0();

    return (
        <div className="form-container-m">
        <div className='form-container'>
        <h2>Sign Up</h2>
            <form>
                <input type="text" placeholder="Name" required />
                <input type="tel" placeholder="Number" required />
                <input type="email" placeholder="Email" required />
                <input type="password" placeholder="Password" required />
                <input type="password" placeholder="Confirm Password" required />
                <button type="submit">Sign Up</button>
                <button onClick={() => { loginWithRedirect() }}>Login With Redirect</button>
            </form>
            <p>
                Already have an account? <Link to="/"><span >Login here</span></Link>
            </p>
        </div>
           
        </div>
    )
}

export default SignupForm