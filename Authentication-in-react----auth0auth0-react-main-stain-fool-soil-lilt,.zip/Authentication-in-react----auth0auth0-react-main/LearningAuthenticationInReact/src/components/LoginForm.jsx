import React from 'react'
import { Link } from 'react-router-dom'
import { useAuth0 } from '@auth0/auth0-react'

const LoginForm = () => {

    // if user is logged in we will get this user from this "user" method and with this loginWithRedirect function we can trigger it to
    // make the user redirect to the login page handled with Auth0 and if we add a console.log statement over here with logging the user 
    // init we on a successful login will be able to see the details of the user and use it to our advantage like example profile picture
    // name address etc We also have a method here i.e isAuthenticated and this method has boolean values and it can be used to manage the
    // Authenticated states over our application and we also have a logout method by using which we can trigger the logout functionality
    const { user, loginWithRedirect, isAuthenticated, logout } = useAuth0();

    console.log("Current User", user)

    return (
        <div className="form-container-m">
        <div className='form-container'>
        <h2>Login</h2>
            <form>
                <input type="email" placeholder="Email" required />
                <input type="password" placeholder="Password" required />
                <button type="submit">Login</button>
                <button onClick={() => { loginWithRedirect() }}>Login With Redirect</button>
            </form>
            <p>
                Don't have an account? <Link to="/Signup"><span>Sign up here</span></Link>
            </p>
        </div>
            
        </div>
    )
}

export default LoginForm