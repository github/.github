import React from 'react'
import { useAuth0 } from '@auth0/auth0-react'


const Home = () => {

  const { user, logout } = useAuth0();

  // Access user information (e.g., name, email)
  const userName = user?.name || 'Guest'; // Default to "Guest" if user is not available

  // logging all the available user info from the user object of useAuth0
  console.log(user)
  return (
    <div>
      <h1>Welcome To Home {userName}</h1>
      <button onClick={() => { logout() }}>Logout</button>
    </div>
  )
}

export default Home