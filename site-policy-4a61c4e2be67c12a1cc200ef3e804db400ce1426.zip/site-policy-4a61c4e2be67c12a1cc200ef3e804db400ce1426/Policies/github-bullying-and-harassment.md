---
title: GitHub Bullying and Harassment
versions:
  fpt: '*'
topics:
  - Policy
  - Legal
---

We do not tolerate harassment, bullying, or abuse of any kind, whether directly or by encouraging others to take part in the prohibited conduct. This includes:

- Targeted personal attacks
- Piling on to or orchestrating [disruptive](/github/site-policy/github-disrupting-the-experience-of-other-users) activity in a way that amounts to abuse
- Following another user around the platform in a manner that causes intimidation
- Making sexual advances or comments directed at another individual
- Disingenuously participating in conversation in a way that instigates conflict or undermines sincere discussion
- Creating alternative accounts specifically to evade moderation action taken by GitHub staff or users

Please note, not all unwelcome conduct is necessarily considered harassment. For example, disagreeing with another user or downvoting their comments may not rise to the level of harassment on our platform. In addition, sharing criticism of public figures or projects, or topics of public interest, does not necessarily fall under this policy. However, we encourage you to be mindful in how you engage with other users and the platform, as this activity may still violate our restriction on disrupting the experience of other users.
